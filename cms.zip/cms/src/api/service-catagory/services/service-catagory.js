'use strict';

/**
 * service-catagory service
 */

const { createCoreService } = require('@strapi/strapi').factories;

module.exports = createCoreService('api::service-catagory.service-catagory');
