'use strict';

/**
 * service-catagory router
 */

const { createCoreRouter } = require('@strapi/strapi').factories;

module.exports = createCoreRouter('api::service-catagory.service-catagory');
