'use strict';

/**
 * service-catagory controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::service-catagory.service-catagory');
