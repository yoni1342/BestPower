'use strict';

/**
 * product-category service
 */

const { createCoreService } = require('@strapi/strapi').factories;

module.exports = createCoreService('api::product-category.product-category');
